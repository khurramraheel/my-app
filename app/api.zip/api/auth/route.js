import { NextResponse } from "next/server";


export function POST (){

    

}

export function GET (){

    return NextResponse.json({name:"ali"});

}



// REST API
// POST - data createa 
// PUT - update data
// DELETE - data delete 
// GET - data mgwana