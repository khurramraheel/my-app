"use client";

// import hamesha top per

import "./globals.css";
import Header from "@/components/header/header.js";
import Footer from "@/components/footer/footer";
  import { ToastContainer, toast } from 'react-toastify';



export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet"  />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" ></script>
      </head>
      <body>

        <Header></Header>
        
        <main>
        {/* yeh aapke page.js hote hn */}
        {children}
        </main>

        <Footer></Footer>

        <ToastContainer></ToastContainer>
        
        
        </body>
    </html>
  );
}
