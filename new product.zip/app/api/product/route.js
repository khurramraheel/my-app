import { connectDB } from "@/app/lib/db";
import Product from "@/models/product";
import { NextResponse } from "next/server";


export  async function POST(req){
    connectDB();
    let data = await req.json();
    // data.createdBy = '444';
    let newP = new Product(data);
    await newP.save();
    return NextResponse.json(newP);

}



export async function GET(req){
    await connectDB();

    let obj = {};

      let a1 = req?.nextUrl?.searchParams.get('hello');

      if(a1){
        obj.createdBy = a1;
      }
         
    let p =  await Product.find(obj);
    return NextResponse.json( {products:p} );
}