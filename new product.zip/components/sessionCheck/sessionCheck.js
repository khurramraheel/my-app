import { setUser } from "@/store/userReducer";
import axios from "axios";
import { useEffect } from "react";
import { useDispatch } from "react-redux";

export default function SessionCheck(){

    let dispatch = useDispatch();

    useEffect(function(){

        axios.post('/api/auth', {
            type: 'sessionCheckKaro',
            key: localStorage.getItem('ckey')
        }).then(function(resp){

            dispatch( setUser(resp.data) )

            console.log(resp.data);
        })

    }, [])


    return <></>

}