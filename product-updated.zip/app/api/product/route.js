import { connectDB } from "@/app/lib/db";
import Product from "@/models/product";
import { NextResponse } from "next/server";


export  async function POST(req){
    connectDB();
    let data = await req.json();
    let newP = new Product(data);
    await newP.save();
    return NextResponse.json(newP);

}



export async function GET(req){
    await connectDB();
    let p =  await Product.find();
    return NextResponse.json( {products:p} );
}