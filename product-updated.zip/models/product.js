import mongoose from "mongoose";


export default mongoose.models.product ||  mongoose.model('product', {
    title: String,
    images:[],
    price: Number,
    description: String,
    rating: {
        type: Number,
        // required:true
    }
})